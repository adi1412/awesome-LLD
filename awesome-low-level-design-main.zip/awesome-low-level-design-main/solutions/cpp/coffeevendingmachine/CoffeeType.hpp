#ifndef COFFEE_TYPE_HPP
#define COFFEE_TYPE_HPP

enum class CoffeeType {
    ESPRESSO,
    LATTE,
    CAPPUCCINO,
    AMERICANO
};

#endif 