#include "Game.hpp"
#include <iostream>

int main() {
    Game chess;
    std::cout << "Welcome to Chess!" << std::endl;
    chess.start();
    return 0;
} 