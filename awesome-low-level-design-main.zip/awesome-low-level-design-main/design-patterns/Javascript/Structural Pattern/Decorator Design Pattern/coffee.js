// Base class component

class Coffee {
  cost() {
    return 10; // Base price of coffee is 10
  }
}

module.exports = Coffee;
