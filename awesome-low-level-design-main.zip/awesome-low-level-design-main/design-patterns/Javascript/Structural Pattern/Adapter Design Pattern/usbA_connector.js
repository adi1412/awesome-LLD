// USB A plug class

// Old system

class USB_A_Connector {
  connect() {
    return "USB-A connector connected";
  }
}

module.exports = USB_A_Connector;
