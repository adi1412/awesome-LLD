// Class for lights functionality

class Lights {
  on() {
    console.log("Lights on, take you're seat!");
  }

  off() {
    console.log("Lights off, get ready to see the show!");
  }
}

module.exports = Lights;
