public interface Sole {

    public String soleBuild();
    public String soleMaterial();
}