public interface ShoeLace {

    public String shoeLaceBuild();
    public String shoeLaceMaterial();
}