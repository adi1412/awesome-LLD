public interface ShoeFactory {
    public Sole createShoeSole();
    public ShoeLace createShoeLace();
}
