public class ThinSole implements Sole {

    @Override
    public String soleBuild() {
        return "Thin Plated";
     }

    @Override
    public String soleMaterial() {
        return "Rubber";
    }
    
    
}
