interface State {
    void insertDollar(VendingMachine context);
    void ejectMoney(VendingMachine context);
    void dispense(VendingMachine context);
}
