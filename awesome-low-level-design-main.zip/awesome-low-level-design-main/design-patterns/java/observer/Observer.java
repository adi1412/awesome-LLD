interface Observer {
    void update(float temperature);
}