interface Container<T> {
    Iterator<T> getIterator();
}
