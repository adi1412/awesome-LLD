interface Employee {
    void showDetails();
    double getSalary();
}